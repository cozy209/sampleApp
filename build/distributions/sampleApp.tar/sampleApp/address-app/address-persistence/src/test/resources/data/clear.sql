truncate table targetaddress;
truncate table town;
truncate table address;
truncate table target;
truncate table cursus;
truncate table school;
truncate table schooling;
truncate table user;